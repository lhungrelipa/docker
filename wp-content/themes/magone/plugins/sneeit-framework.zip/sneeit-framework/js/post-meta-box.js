jQuery(document).ready(function($){
	$('.postbox .inside').each(function(){
		$(this).find('.sneeit-control').first().addClass('first');
	});
});