<?php
/*common libraries which can be used everywhere in plugin*/
require_once 'lib-text.php';
require_once 'lib-utilities.php';
require_once 'lib-file.php';
require_once 'lib-enqueue.php';
require_once 'lib-fonts.php';
