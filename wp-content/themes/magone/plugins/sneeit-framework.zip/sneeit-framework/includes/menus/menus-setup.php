<?php
/*process value of menu item before print out*/
function sneeit_setup_menu_fields( $menu_item ) {	
	return $menu_item;
}